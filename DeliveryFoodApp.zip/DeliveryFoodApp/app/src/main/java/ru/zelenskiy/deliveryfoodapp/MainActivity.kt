package ru.zelenskiy.deliveryfoodapp

import android.graphics.Color
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import ru.zelenskiy.deliveryfoodapp.databinding.ActivityMainBinding
import ru.zelenskiy.deliveryfoodapp.item.ItemReceptView
import ru.zelenskiy.deliveryfoodapp.item.ItemReceptViewAdapter

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    var index = 0
    private val adapter = ItemReceptViewAdapter()
    private val imageReceptIdList = listOf(
        R.mipmap.ic_launcher,
        R.drawable.burger,
        R.drawable.ic_launcher_foreground
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()

        //Spiner
        val languages = resources.getStringArray(R.array.Languages)
        val spinner = findViewById<Spinner>(R.id.spinner_filters)
        if (spinner != null)
        {
            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item, languages
            )
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View, position: Int, id: Long
                ) {
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.selected_item) + " " +
                                "" + languages[position], Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        findViewById<Button>(R.id.btn_mode_1).setOnClickListener {
            findViewById<Button>(R.id.btn_mode_1).setBackground(ContextCompat.getDrawable(this, R.drawable.left_btn_active))
            findViewById<Button>(R.id.btn_mode_1).setTextColor(Color.parseColor("#FFFFFF"))
            findViewById<Button>(R.id.btn_mode_2).setBackground(ContextCompat.getDrawable(this, R.drawable.right_btn_disactive))
            findViewById<Button>(R.id.btn_mode_2).setTextColor(Color.parseColor("#B2C3C3C3"))
            findViewById<LinearLayout>(R.id.Resepts).visibility = View.VISIBLE
            findViewById<LinearLayout>(R.id.Restorans).visibility = View.INVISIBLE
        }

        findViewById<Button>(R.id.btn_mode_2).setOnClickListener {
            findViewById<Button>(R.id.btn_mode_2).setBackground(ContextCompat.getDrawable(this, R.drawable.right_btn_active))
            findViewById<Button>(R.id.btn_mode_2).setTextColor(Color.parseColor("#FFFFFF"))
            findViewById<Button>(R.id.btn_mode_1).setBackground(ContextCompat.getDrawable(this, R.drawable.left_btn_disactive))
            findViewById<Button>(R.id.btn_mode_1).setTextColor(Color.parseColor("#B2C3C3C3"))
            findViewById<LinearLayout>(R.id.Resepts).visibility = View.INVISIBLE
            findViewById<LinearLayout>(R.id.Restorans).visibility = View.VISIBLE
        }
    }

    private fun init() {
        binding.apply {
            // Recept Mode
            receptCards.layoutManager = LinearLayoutManager(this@MainActivity)
            receptCards.adapter = adapter
            addListItemRecepts.setOnClickListener {
                if (index > 2) { index = 0 }
                val recept = ItemReceptView(imageReceptIdList[index])
                adapter.addRecept(recept)
                index++
            }
        }
    }
}
