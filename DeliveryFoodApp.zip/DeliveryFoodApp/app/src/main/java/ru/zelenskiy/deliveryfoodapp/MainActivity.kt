package ru.zelenskiy.deliveryfoodapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ru.zelenskiy.deliveryfoodapp.databinding.ActivityMainBinding
import ru.zelenskiy.deliveryfoodapp.item.ItemReceptView
import ru.zelenskiy.deliveryfoodapp.item.ItemReceptViewAdapter

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    var index = 0
    private val adapter = ItemReceptViewAdapter()
    private val imageReceptIdList = listOf(
        R.drawable.burger,
        R.drawable.burger
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {
        binding.apply {
            // Recept Mode
            receptCards.layoutManager = LinearLayoutManager(this@MainActivity)
            receptCards.adapter = adapter
            addListItemRecepts.setOnClickListener {
                if (index > 1) { index = 0 }
                val recept = ItemReceptView(imageReceptIdList[index])
                adapter.addRecept(recept)
                index++
            }
        }
    }
}