package ru.zelenskiy.deliveryfoodapp.item

data class ItemReceptView(val imageReceptId: Int)
