package ru.zelenskiy.deliveryfoodapp.item

data class ItemRestoranView(val imageRestoranId: Int)
