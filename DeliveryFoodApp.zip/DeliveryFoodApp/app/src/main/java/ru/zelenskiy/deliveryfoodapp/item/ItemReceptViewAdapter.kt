package ru.zelenskiy.deliveryfoodapp.item

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ru.zelenskiy.deliveryfoodapp.R
import ru.zelenskiy.deliveryfoodapp.databinding.ReceptCardBinding

class ItemReceptViewAdapter: RecyclerView.Adapter<ItemReceptViewAdapter.ReceptHolder>() {

    val receptList = ArrayList<ItemReceptView>()

    class ReceptHolder(item: View): RecyclerView.ViewHolder(item) {
        val binding = ReceptCardBinding.bind(itemView)
        fun bind(recept: ItemReceptView) = with(binding) {
            ReceptViewImage.setImageResource(recept.imageReceptId)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReceptHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recept_card, parent, false)
        return ReceptHolder(view)
    }

    override fun onBindViewHolder(holder: ReceptHolder, position: Int) {
        holder.bind(receptList[position])
    }

    override fun getItemCount(): Int {
        return receptList.size
    }

    fun addRecept(recept: ItemReceptView) {
        receptList.add(recept)
        notifyDataSetChanged()
    }

}