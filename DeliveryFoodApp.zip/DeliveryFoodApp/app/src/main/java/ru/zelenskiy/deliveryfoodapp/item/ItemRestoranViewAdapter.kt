package ru.zelenskiy.deliveryfoodapp.item

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ru.zelenskiy.deliveryfoodapp.R
import ru.zelenskiy.deliveryfoodapp.databinding.RestoranCardBinding

class ItemRestoranViewAdapter: RecyclerView.Adapter<ItemRestoranViewAdapter.RestoranHolder>() {

    val restoranList = ArrayList<ItemRestoranView>()

    class RestoranHolder(item: View): RecyclerView.ViewHolder(item) {
        val binding = RestoranCardBinding.bind(itemView)
        fun bind(restoran: ItemRestoranView) = with(binding) {
            RestoranViewImage.setImageResource(restoran.imageRestoranId)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestoranHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.restoran_card, parent, false)
        return RestoranHolder(view)
    }

    override fun onBindViewHolder(holder: RestoranHolder, position: Int) {
        holder.bind(restoranList[position])
    }

    override fun getItemCount(): Int {
        return restoranList.size
    }

    fun addRestoran(restoran: ItemRestoranView) {
        restoranList.add(restoran)
        notifyDataSetChanged()
    }

    fun showAll(list: List<ItemRestoranView>) {
        restoranList.clear()
        restoranList.addAll(list)
        notifyDataSetChanged()
    }
}