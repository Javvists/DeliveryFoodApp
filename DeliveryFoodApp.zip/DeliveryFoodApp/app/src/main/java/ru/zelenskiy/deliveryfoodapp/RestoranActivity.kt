package ru.zelenskiy.deliveryfoodapp

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ru.zelenskiy.deliveryfoodapp.databinding.ActivityMainBinding
import ru.zelenskiy.deliveryfoodapp.item.ItemRestoranView
import ru.zelenskiy.deliveryfoodapp.item.ItemRestoranViewAdapter

class RestoranActivity: AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    var index = 0
    private val adapter = ItemRestoranViewAdapter()
    private val imageRestoranIdList = listOf(
        R.drawable.burger,
        R.drawable.burger
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {
        binding.apply {
            //Restoran Mode
            findViewById<RecyclerView>(R.id.restoranCards).layoutManager = LinearLayoutManager(this@RestoranActivity)
            findViewById<RecyclerView>(R.id.restoranCards).adapter = adapter
            findViewById<Button>(R.id.addListItemRestorans).setOnClickListener {
                if (index > 1) { index = 0 }
                val restoran = ItemRestoranView(imageRestoranIdList[index])
                adapter.addRestoran(restoran)
                index++
            }
        }
    }

}